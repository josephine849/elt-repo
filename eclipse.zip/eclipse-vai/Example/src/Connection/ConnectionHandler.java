package Connection;

import java.sql.DriverManager;

import java.sql.Connection;


public class ConnectionHandler {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("con Handler");
			con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/chart","root","vaishu");
		}
		catch(Exception e){}
		
		return con;
	}
}
