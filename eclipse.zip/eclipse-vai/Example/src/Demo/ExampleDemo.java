package Demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ExampleDemo")
public class ExampleDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ExampleDemo() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/chart","root","vaishu");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select source,percentage from air_pollution");
			out.println("Source"+" "+"Air_pollution <br />");
			while (rs.next()) {
				out.println("\n"+rs.getString(1) + " " + rs.getString(2)+"<br />");
				
				}
		}
		catch (Exception e){
			out.println("Pie chart "+e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
